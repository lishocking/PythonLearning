======
dirbot
======

Deprecation notice (March 2017)
===============================

**This project is now deprecated.**

http://dmoz.org is no more and Scrapy's tutorial has been re-written
against http://quotes.toscrape.com/.

Please refer to https://github.com/scrapy/quotesbot for a more relevant
and up-to-date educational project on how to get started with Scrapy.
